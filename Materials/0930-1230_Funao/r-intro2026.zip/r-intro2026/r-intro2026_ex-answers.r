##################################################
# ���K���A���K���A�h��̉𓚗�
##################################################



### ���K 1 ###

sqrt(2)
1 + 
2
log(2)
help(log)

install.packages(c("tidyverse","readxl","haven"), dep=T)

setwd("C:/temp")
getwd()



### ���K ###

sqrt(2)
1 + 
2
log(2)
help(log)
setwd("C:/temp")
getwd()



### ���K 2 ###

x <- 2
3 + x^2
a <- 1.5 -> b
a
b
trunc(a)   # ��������
floor(a)   # �؂艺���Ȃ̂ŁA���̒l�̏ꍇ�� trunc(a) �ƌ��ʂ��قȂ�

x   <- c(9,8,7,6,5,4,3,2,1)
x   <- 9:1
x   <- seq(9, 1, -1)
y   <- seq(2, 8,  2)
x[4]
( z <- x[c(2,4,6,8)] )
( z <- x[y] )
mean(x); mean(z)
sd(x)  ; sd(z)
( s <- summary(x) )
s[3]
s["Median"]



### ���K 3 ###

x <- 1
is.integer(x)
str(x)
typeof(x)
y <- as.integer(x)
is.integer(y)
str(y)
typeof(y)
is.wholenumber <- function(x) { abs(x-round(x)) < (tol=.Machine$double.eps^0.5) }
is.wholenumber(x)

x <- "1,2,3,4,5"
nchar(x)
length(x)
substring(x, 5, 5)

( y <- unlist(strsplit(x, ",")) )
is.numeric(y)
is.character(y)
str(y)
typeof(y)

( z <- as.numeric(y) )
is.numeric(z)



### ���K 4 ###

myfunc1 <- function(x) {
  return(x^2)
}
myfunc1(3)

myfunc2 <- function(x, y) return(x^y)
myfunc2(4,3)

myfunc3 <- function(x, y) {
  syou  <- x %/% y
  amari <- x %%  y
  return(c(syou, amari))
}
myfunc3(5,3)



### ���K 5 ###

x <- 2
y <- 3
x < 1; y < 3; x <= y
(x < 1) && (x <= y); (x < 1) || (x <= y); !(x <= y)

myone <- function(x) {
  if (x == 1) return(1)
}
myone(1); myone(2)

myindex <- function(x) {
  if (x == 1) return(1)
  else        return(0)
}
myindex(1); myindex(2)

myindex <- function(x) {
  y <- ifelse(x == 1, 1, 0)
  return(y)
}
myindex(1); myindex(2)

mymax <- function(x, y) {
  if (x == y) return(x)
  else        return( max(x,y) )
}
mymax(2,2); mymax(2,3)

mymax <- function(x, y) {
  return( max(x,y) )
}
mymax(2,2); mymax(2,3)



### ���K 6 ###

myprod <- function (n) {
  x <- 1
  for (i in 1:n) x <- x * i
  return(x)
}
myprod(5)

myprod <- function (n) {
  x <- 1
  for (i in 1:n) x <- x * i
  y <- paste("1����",n,"�܂ł̐�:", sep="")
  print(y)
  return(x)
}
myprod(5)

myprod <- function (n) {
  x <- 1
  for (i in 1:n) x <- x * i
  y <- paste("1����", n, "�܂ł̐�: ", x, "\n", sep="")
  cat(y)
 #return( invisible(x) )
}
myprod(5)



### ���K 7 ###

library(tidyverse)

setwd("c:/temp")
getwd()

sex    <- c("F","F","M","M","M")
height <- c(160,165,170,175,180)
weight <- c( 50, 65, 60, 55, 70)
( mydata <- data.frame(SEX=sex, HEIGHT=height, WEIGHT=weight) )

write_csv(mydata, "c:/temp/mydata.csv")
mydata <- read_csv("c:/temp/mydata.csv")

tmp <- filter(mydata, SEX=="M")    # SEX=="M" �𖞂������R�[�h
tmp <- select(tmp, HEIGHT, WEIGHT) # �ϐ�HEIGHT, WEIGHT�ɍi��
summary(tmp)                       # �v�񓝌v��



### ���K 8 ###

library(tidyverse)
mydata |>
  filter(SEX=="M") |>         # SEX=="M" �𖞂������R�[�h
  select(HEIGHT, WEIGHT) |>   # �ϐ�HEIGHT, WEIGHT�ɍi��
  summary()                   # �v�񓝌v��



### ���K 9 ###

base <- ggplot(tg, aes(x=len, color=supp))
base + geom_histogram()
base + geom_density()

base <- ggplot(tg, aes(x=dose, y=len, color=supp))
base + geom_point() + geom_smooth(method=lm, se=F)
ggplot(tg, aes(x=dose, y=len, color=supp)) +
  geom_point() + 
  geom_smooth(method=lm, se=F)



### ���K 10 ###

( MS <- ToothGrowth |>
        group_by(supp, dose) |>
        summarise(m=mean(len)) )

ggplot(MS, aes(x=dose, y=m, color=supp, fill=supp)) +
  geom_col()

ggplot(MS, aes(x=dose, y=m, color=supp, fill=supp)) +
  geom_col(position = "dodge")

ggplot(MS, aes(x=dose, y=m, color=supp, fill=supp)) +
  geom_col(position = "dodge") +
  geom_hline(yintercept=15, color="green") +
  scale_color_manual(values=c("red","blue")) +
  scale_fill_manual(values=c("pink", "lightblue")) +
  theme(legend.position="inside", legend.position.inside=c(0.9,0.9)) +
  xlab("Dose") + ylab("Mean Length") + ggtitle("Bar Chart") + 
  scale_x_continuous(limits=c(0,2.5), breaks=c(0.5,1,2), labels=c("0.5mg","1.0mg","2.0mg")) +
  scale_y_continuous(limits=c(0,35), breaks=seq(0,30,10), labels=c("0mm","10mm","20mm","30mm"))



### ���K 11 ###

ifelse

quantile                 # ���s
methods(quantile)        # �m�F��quantile.default�H
quantile.default         # ���s
stats::quantile.default  # ���s
stats:::quantile.default # �����I

stats:::median.default

mymedian <- function (x) {
  n    <- length(x)
  half <- (n + 1) %/% 2
  if (n%%2 == 1) sort(x, partial=half)[half]
  else mean(sort(x, partial=half+0:1)[half + 0:1])
}
x <- 1:9; y <- 1:10
median(x); mymedian(x); median(y); mymedian(y)

##################################################

### �h�� 1 ###

y <- c(1, 2, 3, 4, 5)
y
Y
mean(y)
sd(y)
z <- c(y, 9)
z[6]
z[3] <- 7
z

x <- 101:200
x <- seq(101, 200, by=1)

( y <- seq(1, 100, by=2) )
( odds <- x[y] )
length(odds)



### �h�� 2 ###

x <- c("L", "M", "H", "L")
( y <- factor(x, levels=c("L", "M", "H")) )

table(y)
nlevels(y)
levels(y)        # ���݂̐������m�F
levels(y) <- 1:3 # ������ύX
factor(c(1,2,3,1)) == y

( z <- factor(x, levels=c("L", "M")) )
addNA(z)
z[2]
( u <- z[c(1,4)] )
droplevels(u)



### �h�� 3 ###

nabe <- function(value) {
  if      (value%%3 == 0 && value%%5 ==0) result <- "Z"
  else if (value%%3 == 0)                 result <- "X"
  else if (value%%5 == 0)                 result <- "Y"
  else                                    result <- value

  return(result)
}
nabe(10); nabe(11); nabe(12); nabe(15)

myprod2 <- function (n) {
  x <- 1
  for (i in 1:n) {
    if (i %% 2 == 1) x <- x * i
  }
  return(x)
}
myprod2(7)   # 1�~3�~5�~7

myprod3 <- function (n) {
  x <- 1
  for (i in 1:n) {
    if (n %% 2 == 1) {
      if (i %% 2 == 1) x <- x * i
    }
    else if (i %% 2 == 0) x <- x * i
  }
  return(x)
}

myprod3(5)   # 1�~3�~5
myprod3(6)   # 2�~4�~6



### �h�� 4 ###

library(tidyverse)

id        <- c(1, 2, 3, 4, 5)
sex       <- c("F","F","M","M","M")
height    <- c(160,165,170,175,180)
weight    <- c( 50, 65, 60, 55, 70)

( mydata2 <- data.frame(ID=id, SEX=sex, WEIGHT=weight) )
( mydata2 <- mutate(mydata2, HEIGHT=height) )
( mydata2 <- filter(mydata2, SEX=="F")      )
( mydata2 <- select(mydata2, ID, HEIGHT)    )

( mydata2 <- data.frame(ID=id, SEX=sex, WEIGHT=weight) )
mydata2 %>%
  mutate(HEIGHT=height) %>%
  filter(SEX=="F") %>%
  select(ID, HEIGHT) %>%
  summary()



### �h�� 5 ###

base <- ggplot(ToothGrowth, aes(x=dose, y=len, color=supp, shape=supp))
base + geom_point()

pd <- position_dodge(0.2)
base + geom_point(position=pd)

base + geom_point(aes(size=supp), position=pd)

base + geom_point(aes(size=supp), position=pd) + 
  scale_color_manual(values=c("red","black")) +
  scale_shape_manual(values=c(1,17)) +
  scale_size_manual(values=c(5,2))

base + geom_point(aes(size=supp), position=pd) + 
  geom_smooth(method=lm, se=F) + 
  scale_color_manual(values=c("red","black")) +
  scale_shape_manual(values=c(1,17)) +
  scale_size_manual(values=c(5,2)) +
  theme(legend.position="bottom") +
  xlab("Dose") + ylab("") + ggtitle("Scatter Plot for Tooth Length") + 
  scale_x_continuous(limits=c(0,2.5), breaks=c(0.5,1,2), labels=c("0.5mg","1.0mg","2.0mg")) +
  scale_y_continuous(limits=c(0,35), breaks=seq(10,30,10), labels=c("10 mm","20 mm","30 mm"))



### �h�� 6 ###

help(seq)

seq
methods(seq)
seq.default

library(dplyr)
help(union, package="dplyr")
help(union, package="base")
base:::union
base::union(c(1,2,3),c(2,3,4) )

wilcox.test
methods(wilcox.test)
wilcox.test.default
stats::wilcox.test.default
stats:::wilcox.test.default
